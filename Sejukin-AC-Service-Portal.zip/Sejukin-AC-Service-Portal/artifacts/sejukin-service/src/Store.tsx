import { createContext, useContext, useEffect, useMemo, useState, type ReactNode } from 'react';
import { seedOrders, type Role, type ServiceOrder } from './data';

type Session = { role: Role; name: string } | null;
type StoreValue = { orders: ServiceOrder[]; session: Session; toastMessage: string; notify: (message:string)=>void; login:(role:Role)=>void; logout:()=>void; addOrder:(order:ServiceOrder)=>void; patchOrder:(id:string,patch:Partial<ServiceOrder>)=>void; };
const StoreContext = createContext<StoreValue | null>(null);
export function StoreProvider({ children }: { children:ReactNode }) {
  const [orders,setOrders] = useState<ServiceOrder[]>(() => { try { const saved=localStorage.getItem('sejukin-orders'); return saved ? JSON.parse(saved) : seedOrders; } catch { return seedOrders; } });
  const [session,setSession] = useState<Session>(() => { try { const saved=localStorage.getItem('sejukin-session'); return saved ? JSON.parse(saved) : null; } catch { return null; } });
  const [toastMessage,setToastMessage] = useState('');
  useEffect(()=>{localStorage.setItem('sejukin-orders',JSON.stringify(orders));},[orders]);
  useEffect(()=>{if(session) localStorage.setItem('sejukin-session',JSON.stringify(session)); else localStorage.removeItem('sejukin-session');},[session]);
  useEffect(()=>{if(!toastMessage)return;const t=window.setTimeout(()=>setToastMessage(''),3200);return()=>window.clearTimeout(t);},[toastMessage]);
  const value=useMemo<StoreValue>(()=>({
    orders,session,toastMessage,notify:setToastMessage,
    login:(role)=>setSession({role,name:role==='admin'?'Raka Admin':'Dimas Saputra'}),
    logout:()=>setSession(null),
    addOrder:(order)=>setOrders(current=>[order,...current]),
    patchOrder:(id,patch)=>setOrders(current=>current.map(order=>order.id===id?{...order,...patch}:order)),
  }),[orders,session,toastMessage]);
  return <StoreContext.Provider value={value}>{children}</StoreContext.Provider>;
}
export function useStore() { const value=useContext(StoreContext); if(!value) throw new Error('StoreProvider missing'); return value; }
