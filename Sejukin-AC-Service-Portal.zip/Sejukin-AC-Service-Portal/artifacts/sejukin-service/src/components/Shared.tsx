import { Link } from 'wouter';
import { ArrowRight, Snowflake, X } from 'lucide-react';
import { useStore } from '../Store';
import type { Status } from '../data';

export function Brand({ light=false }: { light?:boolean }) {
  return <Link href="/" className={`inline-flex items-center gap-3 ${light?'text-white':''}`} data-testid="link-brand-home"><span className="grid h-10 w-10 place-items-center rounded-2xl bg-[#087f5b] text-white"><Snowflake size={22}/></span><span><b className="brandfont text-xl font-extrabold tracking-tight">sejukin<span className="text-[#087f5b]">.</span></b><small className={`block text-[9px] font-bold uppercase tracking-[.2em] ${light?'text-white/55':'text-gray-400'}`}>Service workspace</small></span></Link>;
}
export function StatusBadge({ status }: { status:Status }) {
  const className=({Pending:'pending',Dispatched:'dispatched','In Progress':'progress','Awaiting Approval':'approval',Completed:'completed'})[status];
  return <span data-testid={`status-order-${status.toLowerCase().replaceAll(' ','-')}`} className={`badge ${className}`}><span className="h-1.5 w-1.5 rounded-full bg-current"/>{status}</span>;
}
export function Toast() {
  const {toastMessage,notify}=useStore();
  if(!toastMessage)return null;
  return <div role="status" className="toast-enter fixed bottom-5 right-5 z-[90] flex max-w-sm items-center gap-3 rounded-xl bg-[#14231f] px-4 py-3 text-white shadow-xl"><span className="grid h-7 w-7 shrink-0 place-items-center rounded-lg bg-[#c7f36b] font-bold text-[#14231f]">✓</span><span className="text-sm font-semibold">{toastMessage}</span><button onClick={()=>notify('')} aria-label="Tutup notifikasi" className="ml-2 text-white/60" data-testid="button-dismiss-toast"><X size={16}/></button></div>;
}
export function PublicHeader() {
  return <header className="flex items-center justify-between border-b border-[#e8ede9] bg-white/90 px-5 py-4 md:px-10"><Brand/><nav className="flex items-center gap-3"><a href="#cara-kerja" className="hidden text-sm font-semibold text-[#64716c] md:block">Cara kerja</a><Link href="/login" className="btn btn-light flex items-center gap-2" data-testid="link-staff-login">Staff / Admin Login <ArrowRight size={15}/></Link></nav></header>;
}
export function FieldLabel({ label, children, className='' }: { label:string; children:any; className?:string }) {
  return <label className={`block ${className}`}><span className="label">{label}</span>{children}</label>;
}
