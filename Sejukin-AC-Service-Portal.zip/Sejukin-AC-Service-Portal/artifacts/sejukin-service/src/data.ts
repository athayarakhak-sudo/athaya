export type Status = 'Pending' | 'Dispatched' | 'In Progress' | 'Awaiting Approval' | 'Completed';
export type Role = 'admin' | 'staff';
export type Technician = { name: string; initials: string; area: string; skills: string[]; capacity: number };
export type ServiceOrder = {
  id: string; customerName: string; phone: string; address: string; room: string; brand: string; model: string;
  capacityPk: string; refrigerant: string; complaints: string[]; notes: string; services: string[]; date: string;
  time: string; technicianName: string; status: Status; partsCost: number; serviceFee: number;
  checks: Record<string, boolean>; approvedBy: string; completedAt: string;
};
export const technicians: Technician[] = [
  { name:'Dimas Saputra', initials:'DS', area:'Lowokwaru', skills:['Split AC','R32','Electrical'], capacity:3 },
  { name:'Andi Pratama', initials:'AP', area:'Klojen', skills:['Split AC','R410A','Cleaning'], capacity:3 },
  { name:'Fajar Nugroho', initials:'FN', area:'Blimbing', skills:['Multi-split','R32','Installation'], capacity:2 },
  { name:'Rizky Hidayat', initials:'RH', area:'Sukun', skills:['Split AC','R22','Electrical'], capacity:3 },
];
export const indoorChecks = ['Evaporator','Fan/Blower Indoor','Swing','Tegangan Input','Thermis/Temp Sensor'];
export const outdoorChecks = ['Kondensor','Fan Outdoor','Kapasitor','Tekanan Freon','Arus/Ampere'];
export const serviceTypes = ['Pengecekan','Service/Cuci','Tambah AC','Isi Refrigerant','Bongkar','Pasang','Bongkar & Pasang','Perbaikan'];
export const seedOrders: ServiceOrder[] = [
  { id:'SJ-261012-01',customerName:'Nadia Putri',phone:'0812-3456-7890',address:'Jl. Ijen No. 18, Klojen, Malang',room:'Main bedroom',brand:'Daikin',model:'Split wall-mounted',capacityPk:'1 PK',refrigerant:'R32',complaints:['Tidak dingin'],notes:'AC kurang dingin sejak kemarin.',services:['Service/Cuci','Pengecekan'],date:'2026-10-12',time:'10:00–12:00',technicianName:'Dimas Saputra',status:'In Progress',partsCost:100000,serviceFee:250000,checks:{Evaporator:true,'Fan/Blower Indoor':true,Swing:true} ,approvedBy:'',completedAt:''},
  { id:'SJ-261012-02',customerName:'Bima Prakoso',phone:'0813-1111-2222',address:'Jl. Soekarno Hatta, Lowokwaru, Malang',room:'Ruang keluarga',brand:'Panasonic',model:'Inverter split',capacityPk:'1.5 PK',refrigerant:'R410A',complaints:['Mati total'],notes:'Indoor tidak menyala.',services:['Perbaikan'],date:'2026-10-12',time:'13:00–15:00',technicianName:'Andi Pratama',status:'Dispatched',partsCost:0,serviceFee:0,checks:{},approvedBy:'',completedAt:''},
  { id:'SJ-261012-03',customerName:'Siti Rahma',phone:'0857-4444-5555',address:'Perum Griya Shanta, Blimbing, Malang',room:'Kamar anak',brand:'LG',model:'Dual inverter',capacityPk:'0.75 PK',refrigerant:'R32',complaints:['Tidak dingin','Lainnya'],notes:'Kadang menetes dari indoor.',services:['Service/Cuci','Tambah AC'],date:'2026-10-12',time:'15:00–17:00',technicianName:'',status:'Pending',partsCost:0,serviceFee:0,checks:{},approvedBy:'',completedAt:''},
  { id:'SJ-261011-04',customerName:'Arif Setiawan',phone:'0819-0000-1212',address:'Jl. Tidar, Sukun, Malang',room:'Ruang kerja',brand:'Sharp',model:'Split standard',capacityPk:'1 PK',refrigerant:'R22',complaints:['Tidak dingin'],notes:'',services:['Isi Refrigerant'],date:'2026-10-11',time:'08:00–10:00',technicianName:'Rizky Hidayat',status:'Completed',partsCost:175000,serviceFee:350000,checks:{},approvedBy:'Arif Setiawan',completedAt:'2026-10-11'},
  { id:'SJ-261011-05',customerName:'Maya Lestari',phone:'0822-4567-1111',address:'Jl. Veteran, Klojen, Malang',room:'Kamar utama',brand:'Daikin',model:'Split',capacityPk:'2 PK',refrigerant:'R32',complaints:['Lainnya'],notes:'Bunyi berisik dari outdoor.',services:['Perbaikan'],date:'2026-10-11',time:'13:00–15:00',technicianName:'Fajar Nugroho',status:'Awaiting Approval',partsCost:250000,serviceFee:400000,checks:{Evaporator:true,'Fan/Blower Indoor':true,Swing:true,'Tegangan Input':true,'Thermis/Temp Sensor':true,Kondensor:true,'Fan Outdoor':true,Kapasitor:true,'Tekanan Freon':true,'Arus/Ampere':true},approvedBy:'',completedAt:''},
];
export const rupiah = (value:number) => `Rp ${Math.round(value || 0).toLocaleString('id-ID')}`;
