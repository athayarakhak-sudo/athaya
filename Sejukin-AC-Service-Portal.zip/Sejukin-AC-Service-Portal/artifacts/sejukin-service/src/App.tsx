import { type ReactNode, useEffect } from 'react';
import { Route, Switch, useLocation, Router as WouterRouter } from 'wouter';
import { StoreProvider, useStore } from './Store';
import { Toast } from './components/Shared';
import Admin from './pages/Admin';
import Login from './pages/Login';
import Portal from './pages/Portal';
import Staff from './pages/Staff';

function Protected({ role, children }: { role:'admin'|'staff'; children:ReactNode }) {
  const {session}=useStore();
  const [,setLocation]=useLocation();
  useEffect(()=>{if(!session)setLocation('/login');else if(session.role!==role)setLocation(session.role==='admin'?'/admin':'/staff');},[session,role,setLocation]);
  if(!session||session.role!==role)return <div className="min-h-[100dvh] bg-[#f6f8f5]"/>;
  return <>{children}</>;
}
function NotFound() {
  return <main className="grid min-h-[100dvh] place-items-center bg-[#f6f8f5] p-6 text-center"><div><p className="text-xs font-extrabold uppercase tracking-[.2em] text-[#087f5b]">404 · Sejukin</p><h1 className="mt-3 text-3xl font-extrabold">Halaman tidak ditemukan</h1><p className="mt-2 text-sm text-gray-500">Alamat halaman ini tidak tersedia.</p><a className="btn btn-primary mt-6 inline-block" href="/">Kembali ke portal</a></div></main>;
}
function Router() {
  return <><Switch><Route path="/" component={Portal}/><Route path="/login" component={Login}/><Route path="/admin"><Protected role="admin"><Admin/></Protected></Route><Route path="/staff"><Protected role="staff"><Staff/></Protected></Route><Route component={NotFound}/></Switch><Toast/></>;
}
export default function App() {
  return <StoreProvider><WouterRouter base={import.meta.env.BASE_URL.replace(/\/$/,'')}><Router/></WouterRouter></StoreProvider>;
}
